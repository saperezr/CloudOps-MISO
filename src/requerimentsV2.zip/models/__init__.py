from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

from models.blackListedEmail import BlackListedEmail